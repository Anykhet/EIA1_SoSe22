Samples von freesound.org, Creative Commons 0 License
