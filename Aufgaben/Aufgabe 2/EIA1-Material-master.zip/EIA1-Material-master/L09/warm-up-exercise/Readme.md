Mit diesen kleinen Übungen sollen die Inhalte zu Bedingungen und Schleifen der aktuellen Lektion wiederholt werden:

### Übung A:
In der Skript-Datei finden Sie eine Liste von Namen. Im Frontend soll nun die Gesamtanzahl der Namen ausgegeben werden.

### Übung B: 
Im Frontend sehen Sie die Buttons "Alle Namen (A-Z)" und "Alle Namen (Z-A)". Bei Kilck auf einen Button sollen alle Namen angezeigt werden, einmal alphabetisch auf-, einmal absteigend.

### Übung C:
Bei Klick auf den Button "Alle Namen (außer ...)", sollen entsprechende Namen angezeigt werden.