## Übung zu Bilder und Verweise

Zeigen Sie im HTML Dokument alle Bilder an, die in diesem Verzeichnis abgelegt sind (Logo, Furtwangen, Freiburg, Vögel).