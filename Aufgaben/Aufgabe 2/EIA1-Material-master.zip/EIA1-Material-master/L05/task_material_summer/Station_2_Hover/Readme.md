# Station "Hover und Positionierung"

Positionierung und grundlegende Herangehensweise wie in Station 1.
Darüberhinaus sollen sich die Muscheln verändern, wenn der Nutzer mit der Maus über eine Muschel fährt.
Dafür finden Sie im images-Ordner die Muschel in zwei Zuständen.

![Designvorlage](designvorlage.png)
