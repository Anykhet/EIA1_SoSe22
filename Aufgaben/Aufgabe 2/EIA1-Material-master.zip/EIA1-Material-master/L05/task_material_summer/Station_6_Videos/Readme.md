# Station "Videos und animierte Elemente"

Positionierung und grundlegende Herangehensweise wie in Station 1.

Mit dieser Holiday-Card werden Sie noch einmal verschiede "Bewegt-Bild"-Inhalte einsetzten. Die Muscheln auf der Karte sollen sich drehen, der Weihnachtsbaum soll, etwas verspätet, ordnungsgemäß entsorgt werden. Nutzen Sie für das Video-Tag auch wieder weiterführende Attribute, wie loop oder autoplay, um das Abspielverhalten besser zu steuern.
Darstellung gemäß Designvorlage, d.h. das Videoelement muss an die richtige Stelle plaziert werden (hier hilft "position:absolute").

![Designvorlage](designvorlage.png)
