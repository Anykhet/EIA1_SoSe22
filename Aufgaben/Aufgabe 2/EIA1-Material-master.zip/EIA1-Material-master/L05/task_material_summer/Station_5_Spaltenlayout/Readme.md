# Station "Spaltenlayout"

Positionierung und grundlegende Herangehensweise wie in Station 1.
Diese Holiday-Card soll Text abbilden. Der Text soll in zwei als auch in drei Spalten fließen, gemäß Designvorlage:


![Designvorlage](designvorlage.png)

Für die Umsetzung dieser Aufgabe gibt es (wie immer) viele verschiedene Wege. Sehr komplizierte (Einzel-Objekte mit Positionsangaben) oder sehr einfache (Column-Regel).