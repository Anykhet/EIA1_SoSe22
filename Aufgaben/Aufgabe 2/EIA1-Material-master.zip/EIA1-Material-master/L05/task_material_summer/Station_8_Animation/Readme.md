# Station "CSS Animation"

Positionierung und grundlegende Herangehensweise wie in Station 1.

In der Vorlesung hatten wir Transitions, Animationsmöglichkeiten und Bewegungskurven nach Robert Penner behandelt.
Mit dieser Holiday-Card können die die CSS-Animations Regel einmal einsetzten. Die Muscheln sollen auf der Karte langsam fallen. Am Boden angekommen wiederholt sich die Animation.
Recherchierchen Sie dazu, um mehr über die CSS-Animationen zu erfahren.

![Designvorlage](designvorlage.png)
