# Station "Hover und Positionierung"

Positionierung und grundlegende Herangehensweise wie in Station 1.
Darüberhinaus sollen sich die Sterne verändern, wenn der Nutzer mit der Maus über einen Stern fährt.
Dafür finden Sie im images-Ordner den Stern in zwei Zuständen.

![Designvorlage](designvorlage.png)
