# Station "CSS Animation"

Positionierung und grundlegende Herangehensweise wie in Station 1.
In der Vorlesung hatten wir nur kurz Transitions, Animationsmöglichkeiten und Bewegungskurven nach Robert Penner behandeln können.
Mit dieser Xmas-Card können die die CSS-Animations Regel einmal einsetzten. Die Schneeflocken sollen auf der Karte langsam fallen. Am Boden angekommen wiederholt sich die Animation.
Recherchierchen Sie dazu, um mehr über die CSS-Animationen zu erfahren.

![Designvorlage](designvorlage.png)
