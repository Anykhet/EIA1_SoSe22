# Station "Externe Videos"

Positionierung und grundlegende Herangehensweise wie in Station 1.
Auf dieser Xmas-Card soll ein externen Video eingettet und dargestellt werden.
Darstellung gemäß Designvorlage.

![Designvorlage](designvorlage.png)

Die Banderole sollte **über** dem iFrame-Container/über dem Video liegen. Dafür gibt es verschiedene Lösungen; eine sehr einfache CSS Lösung: z-index.