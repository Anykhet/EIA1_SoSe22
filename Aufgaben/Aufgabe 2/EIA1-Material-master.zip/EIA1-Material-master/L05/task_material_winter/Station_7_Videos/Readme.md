# Station "Videos und animierte Elemente"

Positionierung und grundlegende Herangehensweise wie in Station 1.

Mit dieser Xmas-Card werden Sie noch einmal verschiede "Bewegt-Bild"-Inhalte einsetzten. Die Sterne auf der Karte sollten funkeln, der Weihnachtsbaum soll brennen. Nutzen Sie für das Video-Tag auch wieder weiterführende Attribute, wie loop oder autoplay, um das Abspielverhalten besser zu steuern.
Darstellung gemäß Designvorlage, d.h. das Videoelement muss an die richtige Stelle plaziert werden (hier hilft "position:absolute").

![Designvorlage](designvorlage.png)
